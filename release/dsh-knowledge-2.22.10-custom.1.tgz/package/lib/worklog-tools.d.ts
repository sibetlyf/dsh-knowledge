import type { ToolDefinitionLike } from './runtime.js';
import type { JournalRuntime } from './worklog-runtime.js';
export declare function worklogTools(read?: JournalRuntime['read']): ToolDefinitionLike[];
//# sourceMappingURL=worklog-tools.d.ts.map