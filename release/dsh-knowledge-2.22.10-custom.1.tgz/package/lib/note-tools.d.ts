import type { KnowledgeProvider } from './provider.js';
import { KnowledgeNoteHandleCodec } from './note-reference-handle.js';
import type { RuntimeContextLike, ToolDefinitionLike } from './runtime.js';
import { type KnowledgeHandleCodec } from './retrieval.js';
/** Reads need no semantic grant. Session handles and explicit mutation consent remain independent. */
export declare function registerKnowledgeNoteTools(ctx: RuntimeContextLike, provider: KnowledgeProvider, codec: KnowledgeNoteHandleCodec, knowledgeCodec: KnowledgeHandleCodec, register?: (tool: ToolDefinitionLike) => () => void): void;
//# sourceMappingURL=note-tools.d.ts.map