import type { DatabaseSync } from 'node:sqlite';
import type { SearchHit } from './domain.js';
import { type RecallScoreBreakdown } from './recall-score.js';
export interface RecallUsage {
    sessionId: string;
    turn: string;
    projectId?: string;
    kind: 'auto' | 'search' | 'read';
    ids: string[];
}
export interface RecallRankQuery {
    days?: number;
    base?: string;
    query?: string;
    sort?: string;
    cursor?: string;
    limit?: number;
}
export interface RecallPreference {
    priority: number;
    frictionOverride: number | null;
    revision: number;
}
export interface RecallRankRow extends RecallPreference {
    id: string;
    title: string;
    knowledgeBaseId: string;
    baseName: string;
    documentState: string;
    recalls: number;
    reads: number;
    sessions: number;
    auto: number;
    searches: number;
    lastRecall: number | null;
    friction: number;
    automaticFriction: number;
    incidents: number;
    score: number;
    scoreBreakdown: RecallScoreBreakdown;
}
export interface RecallRankPage {
    items: RecallRankRow[];
    total: number;
    startedAt: number;
    nextCursor?: string;
    asOf: number;
    incidentDocuments: number;
}
export interface RecallPreferencePatch {
    priority?: number;
    frictionOverride?: number | null;
    revision: number;
    reason?: string;
}
export interface FrictionInput {
    requestId: string;
    reason: string;
    severity: number;
}
export declare function validateUsage(value: RecallUsage): void;
export declare function compareRecallHits(a: SearchHit, b: SearchHit): number;
export declare class RecallRankingStore {
    private readonly db;
    constructor(db: DatabaseSync);
    record(value: RecallUsage, namespace?: string, at?: number): void;
    private entry;
    private preference;
    patch(id: string, patch: RecallPreferencePatch): RecallPreference;
    patchMany(items: {
        id: string;
        revision: number;
    }[], priority: number): RecallPreference[];
    incident(id: string, value: FrictionInput): {
        id: string;
    };
    retract(id: string, eventId: string, reason: string): void;
    private audit;
    private friction;
    boost(hits: SearchHit[]): SearchHit[];
    list(query?: RecallRankQuery): RecallRankPage;
    detail(id: string, kind?: string, before?: number): Record<string, unknown>;
}
//# sourceMappingURL=recall-ranking.d.ts.map