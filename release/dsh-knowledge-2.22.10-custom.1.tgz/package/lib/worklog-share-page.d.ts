export interface WorklogSharePageInput {
    apiPrefix: string;
    token: string;
    day: string;
    days: string[];
    markdown: string;
    updated?: number;
    todos?: Array<{
        text: string;
        cat?: string;
        done?: boolean;
        carriedFrom?: string;
    }>;
    title?: string;
}
export declare function renderWorklogSharePage(input: WorklogSharePageInput): string;
//# sourceMappingURL=worklog-share-page.d.ts.map