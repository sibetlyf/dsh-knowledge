export declare function compareNames(left: string, right: string, options?: Intl.CollatorOptions): number;
export declare function byName<T>(select: (value: T) => string, options?: Intl.CollatorOptions): (left: T, right: T) => number;
export declare function foldName(value: string): string;
//# sourceMappingURL=collation.d.ts.map