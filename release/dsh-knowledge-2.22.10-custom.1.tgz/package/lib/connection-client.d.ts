export interface KnowledgeConnectionView {
    backend: 'local' | 'remote';
    remoteUrl?: string;
    remoteTimeoutMs: number;
    tokenConfigured: boolean;
    canSwitchRemote: boolean;
    writable: boolean;
    managementAvailable: boolean;
    managementPath?: string;
}
export declare class ConnectionRequestError extends Error {
    readonly status: number;
    constructor(message: string, status?: number);
}
export declare function isConnectionView(value: unknown): value is KnowledgeConnectionView;
export declare function createConnectionClient(options?: {
    fetch?: typeof fetch;
    readTimeoutMs?: number;
    now?: () => number;
}): {
    peek: () => KnowledgeConnectionView | undefined;
    request: (method: "GET" | "PUT", body?: Record<string, unknown>, signal?: AbortSignal) => Promise<KnowledgeConnectionView>;
};
//# sourceMappingURL=connection-client.d.ts.map