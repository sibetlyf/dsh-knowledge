import type { ToolDefinitionLike } from './runtime.js';
import type { JournalRuntime } from './worklog-runtime.js';
export declare function calendarTools(calendar?: JournalRuntime['calendar']): ToolDefinitionLike[];
//# sourceMappingURL=calendar-tools.d.ts.map