import type { KnowledgeProvider } from './provider.js';
/** Every click rechecks the source, current mount/tag/project policy and version. */
export declare function readCitation(provider: KnowledgeProvider, raw: string, sessionId: string, sourceKey: () => string): Promise<{
    title: string;
    path: string;
    version: number;
    section: string;
    startLine: number;
    endLine: number;
    totalLines: number;
    lines: {
        number: number;
        text: string;
        clipped: boolean;
    }[];
    truncated: boolean;
}>;
//# sourceMappingURL=citation-reader.d.ts.map