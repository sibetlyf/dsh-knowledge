export interface KnowledgePassage {
    text: string;
    heading: string;
    /** Unicode code-point offsets, identical to knowledge_read pagination. */
    offset: number;
    endOffset: number;
    totalChars: number;
    startLine: number;
    endLine: number;
    truncated: boolean;
    matched: boolean;
}
export interface PassageBlock {
    start: number;
    end: number;
    offset: number;
    startLine: number;
    heading: string;
    sectionId: number | null;
}
export interface PassageSection {
    id: number;
    parentId: number | null;
    level: number;
    heading: string;
}
export interface PassageStructure {
    blocks: PassageBlock[];
    sections: PassageSection[];
    totalChars: number;
}
/** Ephemeral passage selection. The authoritative document is never split or rewritten. */
export declare function selectKnowledgePassage(body: string, query: string, maxChars?: number, structure?: PassageStructure): KnowledgePassage;
/** Fence-aware paragraphs and ATX heading paths; no Markdown rendering or mutation. */
export declare function buildPassageStructure(body: string): PassageStructure;
//# sourceMappingURL=retrieval-passages.d.ts.map