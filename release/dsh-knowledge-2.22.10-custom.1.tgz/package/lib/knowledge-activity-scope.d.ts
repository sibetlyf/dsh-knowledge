import type { ResolvedKnowledgeMount } from './domain.js';
/** Controlled selection, with the same focus/keyboard contract as the web select. */
export declare function KnowledgeActivityScope({ mounts, selectedId, onSelect }: {
    mounts: ResolvedKnowledgeMount[];
    selectedId: string | undefined;
    onSelect(id: string): void;
}): JSX.Element;
//# sourceMappingURL=knowledge-activity-scope.d.ts.map