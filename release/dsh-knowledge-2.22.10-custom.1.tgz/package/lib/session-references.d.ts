/** Bounded, ephemeral references. Never substitute a reference from another session. */
export declare class SessionReferences {
    private readonly max;
    private readonly ttl;
    private readonly now;
    private readonly items;
    private readonly reverse;
    constructor(max?: number, ttl?: number, now?: () => number);
    clear(): void;
    put(session: string, signed: string): string;
    get(ref: string, session: string): string;
    private remove;
}
//# sourceMappingURL=session-references.d.ts.map