import type { KnowledgeProvider } from './provider.js';
import type { AgentLike } from './runtime.js';
export interface TrackingSourcePage {
    id: string;
    name: string;
    revision: string;
    content: string;
    offset: number;
    nextOffset: number | null;
    totalChars: number;
}
/** Host-only grant. The caller must validate this exact persisted binding and
 * its lifetime. Never expose this argument on general model/search tools. */
export interface TrackingSourceBinding {
    sessionId: string;
    reference: string;
}
/** Resolve a selected document by identity, not ranked recall or shortened keywords. */
export declare function readTrackingSource(provider: KnowledgeProvider, agent: AgentLike, reference: string, offset?: number, signal?: AbortSignal, binding?: TrackingSourceBinding): Promise<TrackingSourcePage>;
//# sourceMappingURL=tracking-source.d.ts.map