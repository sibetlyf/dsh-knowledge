import { NoteReplica } from './notes/replica.js';
import { NoteVault } from './notes/vault.js';
import type { CandidateProposal, CandidateBatchReviewResult, ExtractionJobCompletion, ExtractionJobRecord, KnowledgeCandidate, KnowledgeBase, KnowledgeBaseDraft, KnowledgeBasePatch, KnowledgeDraft, KnowledgeEntry, KnowledgeDocument, KnowledgeDocumentIndexRequest, KnowledgeDocumentIndexResult, KnowledgeStats, KnowledgeVersion, KnowledgeMount, KnowledgeMountBatch, KnowledgeMountBatchResult, KnowledgeMountDraft, KnowledgeMountTargetKind, KnowledgeSettings, KnowledgeSettingsPatch, ResolvedKnowledgeMount, DirectWriteResult, ListRequest, ListResult, ReviewDecision, SearchHit, SearchRequest } from './domain.js';
import type { KnowledgeProvider } from './provider.js';
import type { KnowledgeNoteReference, KnowledgeNoteReferenceSource, NoteListRequest, NoteNode, NoteVersion } from './notes/domain.js';
export interface RemoteProviderOptions {
    url: string;
    token: string;
    timeoutMs: number;
    workspaceRoot?: string;
}
export declare class RemoteKnowledgeProvider implements KnowledgeProvider {
    private readonly options;
    readonly mode: "remote";
    readonly noteReplica: NoteReplica | undefined;
    readonly noteVault: NoteVault | undefined;
    private readonly releaseNoteWorkspace;
    recordRecallIncident(id: string, value: import('./recall-ranking.js').FrictionInput, signal?: AbortSignal): Promise<{
        id: string;
    }>;
    private readonly baseUrl;
    constructor(options: RemoteProviderOptions);
    recordRecallUsage(usage: import('./recall-ranking.js').RecallUsage, signal?: AbortSignal): Promise<void>;
    getSettings(signal?: AbortSignal): Promise<KnowledgeSettings>;
    updateSettings(patch: KnowledgeSettingsPatch, signal?: AbortSignal): Promise<KnowledgeSettings>;
    listKnowledgeBases(signal?: AbortSignal): Promise<KnowledgeBase[]>;
    getKnowledgeBase(id: string, signal?: AbortSignal): Promise<KnowledgeBase | undefined>;
    createKnowledgeBase(draft: KnowledgeBaseDraft, signal?: AbortSignal): Promise<KnowledgeBase>;
    updateKnowledgeBase(id: string, draft: KnowledgeBaseDraft, signal?: AbortSignal): Promise<KnowledgeBase>;
    patchKnowledgeBase(id: string, patch: KnowledgeBasePatch, signal?: AbortSignal): Promise<KnowledgeBase>;
    assignKnowledgeBaseGroup(ids: string[], group: string, signal?: AbortSignal): Promise<KnowledgeBase[]>;
    archiveKnowledgeBase(id: string, signal?: AbortSignal): Promise<KnowledgeBase>;
    restoreKnowledgeBase(id: string, signal?: AbortSignal): Promise<KnowledgeBase>;
    deleteKnowledgeBase(id: string, signal?: AbortSignal): Promise<void>;
    listDocuments(knowledgeBaseId?: string, query?: string, signal?: AbortSignal): Promise<KnowledgeDocument[]>;
    listDocumentGroups(knowledgeBaseId: string, signal?: AbortSignal): Promise<import('./document-groups.js').KnowledgeDocumentGroup[]>;
    assignDocumentGroup(knowledgeBaseId: string, ids: string[], group: string, signal?: AbortSignal): Promise<KnowledgeEntry[]>;
    listDocumentIndex(request: KnowledgeDocumentIndexRequest, signal?: AbortSignal): Promise<KnowledgeDocumentIndexResult>;
    getDocument(id: string, signal?: AbortSignal): Promise<KnowledgeDocument | undefined>;
    listMounts(targetKind?: KnowledgeMountTargetKind, targetId?: string, signal?: AbortSignal): Promise<KnowledgeMount[]>;
    upsertMount(draft: KnowledgeMountDraft, signal?: AbortSignal): Promise<KnowledgeMount>;
    applyMountBatch(batch: KnowledgeMountBatch, signal?: AbortSignal): Promise<KnowledgeMountBatchResult>;
    deleteMount(id: string, signal?: AbortSignal): Promise<void>;
    resolveMounts(sessionId: string, projectId?: string, signal?: AbortSignal): Promise<ResolvedKnowledgeMount[]>;
    search(request: SearchRequest, signal?: AbortSignal): Promise<SearchHit[]>;
    stats(signal?: AbortSignal): Promise<KnowledgeStats>;
    list(request: ListRequest, signal?: AbortSignal): Promise<ListResult<KnowledgeEntry>>;
    get(id: string, signal?: AbortSignal): Promise<KnowledgeEntry | undefined>;
    versions(id: string, signal?: AbortSignal): Promise<KnowledgeVersion[]>;
    create(draft: KnowledgeDraft, signal?: AbortSignal): Promise<KnowledgeEntry>;
    update(id: string, draft: KnowledgeDraft, signal?: AbortSignal, expectedVersion?: number): Promise<KnowledgeEntry>;
    finalize(id: string, state: 'resolved' | 'complete', note?: string, signal?: AbortSignal): Promise<KnowledgeEntry>;
    reopen(id: string, signal?: AbortSignal): Promise<KnowledgeEntry>;
    moveDocument(id: string, knowledgeBaseId: string, signal?: AbortSignal): Promise<KnowledgeEntry>;
    archive(id: string, signal?: AbortSignal): Promise<KnowledgeEntry>;
    delete(id: string, signal?: AbortSignal): Promise<void>;
    listNotes(request?: NoteListRequest, signal?: AbortSignal): Promise<NoteNode[]>;
    getNote(id: string, signal?: AbortSignal): Promise<NoteNode | undefined>;
    readNote(id: string, signal?: AbortSignal): Promise<{
        node: NoteNode;
        content: Uint8Array;
    }>;
    listNoteVersions(id: string, limit?: number, signal?: AbortSignal): Promise<NoteVersion[]>;
    readNoteVersion(id: string, version: number, signal?: AbortSignal): Promise<{
        node: NoteNode;
        version: NoteVersion;
        content: Uint8Array;
    }>;
    restoreNoteVersion(id: string, version: number, expectedVersion?: number, signal?: AbortSignal): Promise<NoteNode>;
    createNoteFolder(name: string, parentId?: string | null, signal?: AbortSignal): Promise<NoteNode>;
    createNoteDocument(name: string, parentId?: string | null, content?: string, signal?: AbortSignal): Promise<NoteNode>;
    updateNoteContent(id: string, content: Uint8Array, signal?: AbortSignal, expectedVersion?: number, source?: string): Promise<NoteNode>;
    renameNote(id: string, name: string, signal?: AbortSignal): Promise<NoteNode>;
    moveNote(id: string, parentId: string | null, signal?: AbortSignal): Promise<NoteNode>;
    deleteNote(id: string, signal?: AbortSignal): Promise<void>;
    searchNotes(query: string, limit: number, signal?: AbortSignal): Promise<NoteNode[]>;
    listKnowledgeNoteReferences(knowledgeId: string, signal?: AbortSignal): Promise<KnowledgeNoteReference[]>;
    addKnowledgeNoteReference(knowledgeId: string, noteId: string, source: KnowledgeNoteReferenceSource, sourceSessionId?: string, signal?: AbortSignal): Promise<KnowledgeNoteReference>;
    deleteKnowledgeNoteReference(knowledgeId: string, noteId: string, signal?: AbortSignal): Promise<void>;
    propose(proposal: CandidateProposal, sourceKey?: string, signal?: AbortSignal): Promise<KnowledgeCandidate>;
    writeDirect(proposal: CandidateProposal, sourceKey?: string, signal?: AbortSignal): Promise<DirectWriteResult>;
    listCandidates(status: 'pending' | 'approved' | 'rejected', limit: number, signal?: AbortSignal): Promise<KnowledgeCandidate[]>;
    review(id: string, decision: ReviewDecision, signal?: AbortSignal): Promise<KnowledgeCandidate>;
    approvePendingBatch(limit: number, excludeIds?: string[], signal?: AbortSignal): Promise<CandidateBatchReviewResult>;
    claimExtraction(sourceKey: string, signal?: AbortSignal): Promise<boolean>;
    completeExtraction(sourceKey: string, completion: ExtractionJobCompletion | number, signal?: AbortSignal): Promise<void>;
    failExtraction(sourceKey: string, error: string, signal?: AbortSignal): Promise<void>;
    resetExtraction(sourceKey: string, signal?: AbortSignal): Promise<void>;
    extractionJob(sourceKey: string, signal?: AbortSignal): Promise<ExtractionJobRecord | undefined>;
    writebackProtocol(signal?: AbortSignal): Promise<{
        idempotentDirectWrites: boolean;
    }>;
    close(): Promise<void>;
    private request;
    private requestBytes;
    private withResponse;
    private fetchResponse;
}
export declare class RemoteProviderError extends Error {
    readonly status: number;
    readonly kind?: "timeout" | "cancelled" | "network" | undefined;
    readonly phase?: "headers" | "body" | undefined;
    constructor(message: string, status: number, kind?: "timeout" | "cancelled" | "network" | undefined, phase?: "headers" | "body" | undefined);
}
//# sourceMappingURL=remote-provider.d.ts.map