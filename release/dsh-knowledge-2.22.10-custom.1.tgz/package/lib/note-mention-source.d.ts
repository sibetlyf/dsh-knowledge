import type { InputTriggerSource } from '@deepseek-ai/dsh-client-ui-input-trigger/client';
export declare const NOTE_MENTION_SOURCE = "knowledge-notes";
/** An independent @ source: the host owns keyboard navigation, focus and cancellation. */
export declare function createNoteMentionSource(openNote: (id: string) => void, request?: typeof fetch): InputTriggerSource;
//# sourceMappingURL=note-mention-source.d.ts.map