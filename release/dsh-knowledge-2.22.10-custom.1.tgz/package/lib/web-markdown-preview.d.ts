/** Render knowledge Markdown for the management console without trusting document HTML. */
export declare function renderMarkdown(markdown: string): string;
/** Block-level source locations, assigned after sanitization; never trust HTML attributes. */
export declare function renderMarkdownSource(markdown: string): string;
//# sourceMappingURL=web-markdown-preview.d.ts.map