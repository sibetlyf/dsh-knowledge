import { type KnowledgeCitation } from './knowledge-citations.js';
/** Intercept only our same-origin inline citations; leave ordinary/file links alone. */
export declare function installCitationLinks(open: (citation: KnowledgeCitation) => void, root?: Document): () => void;
//# sourceMappingURL=citation-links.d.ts.map