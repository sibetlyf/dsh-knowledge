/**
 * 健壮纯 TS PDF 文本抽取器
 * 支持 FlateDecode 解压、UTF-16BE 编码、八进制与常见转义符解析、TJ/Tj 操作符提取。
 */
export declare function extractPdfText(buffer: Buffer): string;
//# sourceMappingURL=pdf-parser.d.ts.map