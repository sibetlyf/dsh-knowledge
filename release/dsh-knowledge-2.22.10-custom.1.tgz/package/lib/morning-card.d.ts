export declare function HeroMorningCard({ size, className }: {
    size?: number;
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=morning-card.d.ts.map