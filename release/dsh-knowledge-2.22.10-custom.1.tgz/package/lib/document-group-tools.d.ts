import type { KnowledgeProvider } from './provider.js';
import type { ToolDefinitionLike } from './runtime.js';
import { KnowledgeHandleCodec } from './retrieval.js';
/** Common session tools. No companion-specific permission or dependency. */
export declare function documentGroupTools(provider: KnowledgeProvider, codec: KnowledgeHandleCodec): ToolDefinitionLike[];
//# sourceMappingURL=document-group-tools.d.ts.map