import type { DatabaseSync } from 'node:sqlite';
/** Detect local writes and commits from other connections without modifying SQLite. */
export declare function sqliteRevision(db: DatabaseSync): string;
//# sourceMappingURL=sqlite-revision.d.ts.map