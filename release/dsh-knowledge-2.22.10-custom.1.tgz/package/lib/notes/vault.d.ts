import type { NoteNode } from './domain.js';
export interface VaultNotes {
    readVersion?(id: string, version: number): Promise<{
        content: Uint8Array;
    }> | {
        content: Uint8Array;
    };
    relocate?(id: string, name: string, parentId: string | null, expected: string): Promise<NoteNode>;
    all(): NoteNode[] | Promise<NoteNode[]>;
    read(id: string): Promise<{
        node: NoteNode;
        content: Uint8Array;
    }> | {
        node: NoteNode;
        content: Uint8Array;
    };
    update(id: string, bytes: Uint8Array, version: number): Promise<NoteNode>;
    create(kind: 'folder' | 'document', name: string, parentId: string | null, content: Uint8Array): Promise<NoteNode>;
}
/** Plain files are an interoperable projection. The journal lives outside the vault. */
export declare class NoteVault {
    readonly path: string;
    private readonly notes;
    private readonly manifestPath;
    private readonly autoStart;
    private readonly timing;
    private mappings;
    private persistedManifest;
    private running;
    private timer;
    private idleScans;
    private stopped;
    private loaded;
    private rescan;
    private token;
    private rootIdentity;
    private markerIdentity;
    private volumeUUID;
    private checkedVolume;
    private watcher;
    private debounce;
    private blockedDirectories;
    private previousSnapshot;
    private observations;
    private events;
    private trashFolder;
    private warning;
    constructor(path: string, notes: VaultNotes, manifestPath: string, autoStart?: boolean, timing?: {
        stableMs: number;
        missingMs: number;
        now: () => number;
    });
    status(): {
        path: string;
        events: {
            id: string;
            version: number;
            path: string;
            action: string;
            time: string;
        }[];
        recycle: {
            id: string;
            path: string;
            time: string;
        }[];
        externalIssues: {
            id: string;
            path: string;
        }[];
        warning: string;
        externalConflicts: number;
        externalMissing: number;
    };
    private safe;
    private bytes;
    private persist;
    scan(): Promise<void>;
    private cycle;
    private reconcileNativeDeletes;
    private nativeComponent;
    private reconcileNativePaths;
    private record;
    private stable;
    private blocked;
    private recycled;
    private inTrash;
    private rebindDevice;
    private verifyRoot;
    private ensureFolder;
    private reconcilePaths;
    private exclusive;
    restore(id: string): Promise<void>;
    private restoreNow;
    conflictDetail(id: string): Promise<{
        id: string;
        directory: boolean;
        candidates: {
            path: string;
            signature: string;
        }[];
        path: string;
        version: number;
        fingerprint: string | null;
        externalHash: string | null;
        applicationText: string;
        externalText: string | null;
    }>;
    private detailNow;
    resolveExternal(id: string, choice: string, expected: string, externalHash: string | null): Promise<void>;
    private resolveNow;
    linkExternalPath(id: string, path: string, signature: string, expected: string): Promise<void>;
    close(): Promise<void>;
}
//# sourceMappingURL=vault.d.ts.map