import { type NoteNode, type NoteListRequest, type NoteVersion } from './domain.js';
export type NoteTransport = (path: string, method?: string, body?: unknown) => Promise<unknown>;
export declare class NoteReplica {
    private readonly remote;
    private readonly db;
    private running;
    private tail;
    private timer;
    private closed;
    private closing;
    private resync;
    private message;
    private state;
    constructor(path: string, remote: NoteTransport, autoStart?: boolean);
    start(): void;
    private serial;
    private row;
    private rows;
    private node;
    private save;
    status(): {
        mode: string;
        state: string;
        message: string;
        pending: number;
        conflicts: {
            id: string;
            name: string;
            reason: string | null;
        }[];
        cached: number;
    };
    all(): NoteNode[];
    list(request?: NoteListRequest): NoteNode[];
    get(id: string): NoteNode | undefined;
    read(id: string): {
        node: NoteNode;
        content: Buffer;
    };
    versions(id: string, limit?: number): NoteVersion[];
    readVersion(id: string, version: number): {
        node: NoteNode;
        version: {
            noteId: string;
            version: number;
            name: string;
            mediaType: string | null;
            size: number;
            sha256: string;
            createdAt: string;
        };
        content: Buffer<ArrayBuffer>;
    };
    private destination;
    private transaction;
    create(kind: NoteNode['kind'], name: string, parentId?: string | null, content?: Uint8Array, mediaType?: string | null): Promise<NoteNode>;
    change(id: string, patch: {
        name?: string;
        parentId?: string | null;
        content?: Uint8Array;
    }, expectedVersion?: number, expectedFingerprint?: string, source?: string): Promise<{
        name: string;
        parentId: string | null;
        size: number;
        sha256: string | null;
        version: number;
        updatedAt: string;
        id: string;
        kind: import("./domain.js").NoteNodeKind;
        mediaType: string | null;
        editable: boolean;
        createdAt: string;
    }>;
    subtree(id: string): NoteNode[];
    delete(id: string): Promise<void>;
    private descendantRows;
    restore(id: string, version: number, expected?: number): Promise<{
        name: string;
        parentId: string | null;
        size: number;
        sha256: string | null;
        version: number;
        updatedAt: string;
        id: string;
        kind: import("./domain.js").NoteNodeKind;
        mediaType: string | null;
        editable: boolean;
        createdAt: string;
    }>;
    conflictDetail(id: string): Promise<{
        localVersion: number;
        remoteFingerprint: string | null;
        localText: string;
        remoteText: string;
        canKeepLocal: boolean;
    }>;
    resolve(id: string, choice: 'remote' | 'local', expectedRemote: string | null, expectedLocal: number): Promise<void>;
    private checkInstance;
    private bytes;
    sync(): Promise<void>;
    private cycle;
    private pull;
    private depth;
    private conflict;
    close(): Promise<void>;
}
//# sourceMappingURL=replica.d.ts.map