/** Bounded, conservative line merge. Multiple/overlapping edit regions remain conflicts. */
export declare function mergeVaultText(base: Uint8Array, local: Uint8Array, external: Uint8Array): Buffer | null;
//# sourceMappingURL=vault-merge.d.ts.map