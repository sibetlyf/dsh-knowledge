import type { NoteNode } from './domain.js';
export declare const NOTE_SYNC_PROTOCOL = 1;
export interface NoteSyncChange {
    instance: string;
    operationId: string;
    id: string;
    base: string | null;
    subtree?: string;
    value: {
        kind: NoteNode['kind'];
        name: string;
        parentId: string | null;
        mediaType: string | null;
        content: string;
    } | null;
}
export interface NoteManifest {
    protocol: number;
    instance: string;
    revision: string;
    nodes: NoteNode[];
}
export declare function noteFingerprint(node: NoteNode | undefined | null): string | null;
export declare function treeFingerprint(nodes: NoteNode[]): string;
export declare function hash(value: string | Uint8Array): string;
export declare function syncError(status: number, message: string): Error;
//# sourceMappingURL=sync-protocol.d.ts.map