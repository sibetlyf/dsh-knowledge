/**
 * External editors do not honor application locks. Move the previous inode to
 * history, then install with an exclusive link instead of rename-overwriting.
 * A concurrent editor's new file wins; an open old inode remains in history.
 */
export declare function installVaultFile(target: string, bytes: Uint8Array, expectedHash: string | null): Promise<boolean>;
//# sourceMappingURL=vault-file.d.ts.map