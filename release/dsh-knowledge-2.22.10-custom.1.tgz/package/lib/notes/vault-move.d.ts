export interface VaultMove {
    from: string;
    to: string;
    stage: string;
    identity: string;
    directory: boolean;
    name: string;
    parentId: string | null;
    reservation?: string;
}
/** Durable staging is retained. Never replace a destination containing another file. */
export declare function moveVaultEntry(move: VaultMove, checkpoint?: () => Promise<void>): Promise<void>;
//# sourceMappingURL=vault-move.d.ts.map