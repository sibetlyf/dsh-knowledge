import type { IncomingMessage, ServerResponse } from 'node:http';
import type { NoteReplica } from './replica.js';
import type { NoteVault } from './vault.js';
export interface NoteWorkspace {
    replica?: NoteReplica | undefined;
    vault?: NoteVault | undefined;
}
export declare function handleNoteWorkspace(workspace: NoteWorkspace, path: string, url: URL, req: IncomingMessage, res: ServerResponse): Promise<boolean>;
//# sourceMappingURL=workspace-http.d.ts.map