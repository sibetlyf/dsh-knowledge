/** Disk Arbitration supplies the filesystem UUID for local macOS volumes. */
export declare function vaultVolumeUUID(path: string): Promise<string | undefined>;
//# sourceMappingURL=vault-volume.d.ts.map