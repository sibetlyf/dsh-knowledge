export interface VaultEntry {
    path: string;
    directory: boolean;
    identity: string;
    signature: string;
    digest: string | null;
}
export declare function vaultIdentity(path: string): Promise<{
    stat: import("fs").BigIntStats;
    identity: string;
}>;
export declare function readVaultBytes(path: string): Promise<NonSharedBuffer>;
/** A failed/incomplete traversal must never be used to infer deletions. */
export declare function snapshotVault(root: string, previous?: Map<string, VaultEntry>): Promise<Map<string, VaultEntry>>;
//# sourceMappingURL=vault-snapshot.d.ts.map