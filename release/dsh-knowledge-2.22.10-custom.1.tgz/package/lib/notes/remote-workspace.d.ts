import { NoteReplica, type NoteTransport } from './replica.js';
import { NoteVault } from './vault.js';
/** Connection settings can change while the previous provider is retiring. Share its queue. */
export declare function acquireRemoteWorkspace(root: string, transport: NoteTransport): {
    replica: NoteReplica;
    vault: NoteVault;
    release(): Promise<void>;
};
//# sourceMappingURL=remote-workspace.d.ts.map