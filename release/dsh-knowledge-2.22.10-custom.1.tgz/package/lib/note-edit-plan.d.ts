export declare const MAX_NOTE_EDIT_CHARS = 200000;
export interface NoteChangeLocation {
    section: string;
    startLine: number;
    endLine: number;
    beforeChars: number;
    afterChars: number;
}
export interface NoteMutationPreview {
    text: string;
    changeCount: number;
    locations: NoteChangeLocation[];
}
/** Validate every anchor against the SAME snapshot; apply once, never partially.
 * In particular a later edit cannot accidentally match text created by an earlier edit. */
export declare function planNoteContentUpdate(original: string, operation: string, args: Record<string, unknown>): {
    content: string;
    summary: string;
    preview: NoteMutationPreview;
};
//# sourceMappingURL=note-edit-plan.d.ts.map