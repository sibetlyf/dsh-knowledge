/** Opaque, filter-bound keyset cursors. Never interpolate cursor data into SQL. */
export declare function encodePageCursor(scope: string, values: (string | number)[]): string;
export declare function decodePageCursor(cursor: string | undefined, scope: string, types: ('string' | 'number')[]): (string | number)[] | undefined;
//# sourceMappingURL=page-cursor.d.ts.map