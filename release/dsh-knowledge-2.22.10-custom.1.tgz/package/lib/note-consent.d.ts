import type { RuntimeContextLike, ToolRunContextLike } from './runtime.js';
export type ConsentDecision = 'confirm' | 'direct' | 'clarify' | 'revise' | 'reject';
/** Resolve language, not resource permissions. Only real user messages supply consent;
 * proposal text is untrusted data. Signed handles, versions and final scope checks remain mandatory. */
export declare function resolveNoteConsent(ctx: RuntimeContextLike, exec: ToolRunContextLike, input: {
    mode: 'confirm' | 'direct';
    tool: string;
    reason: string;
    preview?: string;
    proposedAfter?: number;
}): Promise<ConsentDecision | undefined>;
//# sourceMappingURL=note-consent.d.ts.map