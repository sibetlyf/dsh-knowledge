export declare const recallScoreSql: {
    readonly recallPoints: "25.0 * recalls / (recalls + 10)";
    readonly readPoints: "25.0 * reads / (reads + 5)";
    readonly sessionPoints: "20.0 * sessions / (sessions + 5)";
    readonly frictionPoints: "0.2 * round(friction, 1)";
    readonly priorityPoints: "5.0 * priority";
};
export type RecallScoreBreakdown = Record<keyof typeof recallScoreSql, number>;
export declare const recallScoreColumns: string;
export declare const recallScoreTotal: string;
//# sourceMappingURL=recall-score.d.ts.map