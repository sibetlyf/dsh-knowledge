export type KnowledgeShareKind = 'document' | 'worklog' | 'base';
export interface KnowledgeShare {
    token: string;
    kind: KnowledgeShareKind;
    id: string;
    title: string;
    createdAt: number;
}
export declare class KnowledgeShareStore {
    private readonly path;
    private rows;
    constructor(databasePath: string);
    private load;
    private flush;
    list(): Promise<KnowledgeShare[]>;
    get(token: string): Promise<KnowledgeShare | undefined>;
    create(id: string, title: string, kind?: KnowledgeShareKind): Promise<KnowledgeShare>;
    revoke(token: string): Promise<boolean>;
}
//# sourceMappingURL=knowledge-share.d.ts.map