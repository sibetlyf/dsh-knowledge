import { type NoteWorkspace } from './notes/workspace-http.js';
import type { KnowledgeConnectionSettings } from './connection.js';
import type { RuntimeContextLike } from './runtime.js';
export declare function registerRemoteManagementProxy(ctx: RuntimeContextLike, prefix: string, current: () => KnowledgeConnectionSettings, localService: {
    current(): {
        writebackProvider?: string;
        writebackModel?: string;
        extractionEveryTurns?: number;
        extractionIdleSeconds?: number;
    };
    update(patch: {
        writebackProvider?: string | null;
        writebackModel?: string | null;
        extractionEveryTurns?: number;
        extractionIdleSeconds?: number;
    }): Promise<{
        writebackProvider?: string;
        writebackModel?: string;
        extractionEveryTurns?: number;
        extractionIdleSeconds?: number;
    }>;
}, workspace?: () => NoteWorkspace): () => void;
//# sourceMappingURL=management-proxy.d.ts.map