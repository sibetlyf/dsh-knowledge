export type KnowledgeColorScheme = 'light' | 'dark';
/** Canonical palette and typography for workspace, activity and shared documents. */
export declare const KNOWLEDGE_PALETTE: Record<KnowledgeColorScheme, Readonly<Record<string, string>>>;
export declare const KNOWLEDGE_FONTS: {
    '--font-ui': string;
    '--font-reading': string;
    '--font-mono': string;
};
/** One interaction scale for the management page and host-owned React surfaces. */
export declare const KNOWLEDGE_INTERACTION: {
    '--knowledge-radius-control': string;
    '--knowledge-radius-menu': string;
    '--knowledge-radius-dialog': string;
    '--knowledge-motion-control': string;
    '--knowledge-motion-menu': string;
    '--knowledge-motion-dialog': string;
    '--knowledge-motion-ease': string;
};
/** SSH-aligned frost for host-side activity and embedded panes; reading tint stays independent. */
export declare const KNOWLEDGE_EMBEDDED_MATERIAL: Record<KnowledgeColorScheme, Readonly<Record<string, string>>>;
export declare function knowledgeDesignCss(scope?: string, dark?: string, systemMode?: boolean): string;
//# sourceMappingURL=design-tokens.d.ts.map