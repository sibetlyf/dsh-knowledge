/** DSH 0.1.7 removed `current` from SessionListState; both generations share this shape. */
export interface SessionListSnapshotLike<K extends string = string> {
    readonly byId: Readonly<Partial<Record<K, {
        readonly retainedBy?: {
            readonly mainView?: number;
        } | undefined;
    }>>>;
    readonly current?: string | undefined;
}
/**
 * Derive the session the main view shows: 0.1.7 keeps it as main-view
 * retention (`retainedBy.mainView`), older hosts keep the plain `current` field.
 */
export declare function deriveCurrentSession<K extends string>(state: SessionListSnapshotLike<K>): K | undefined;
/** Legacy details requires content; new docked tabs support a loaded blank session. */
export declare function availableActivitySession<K extends string>(state: {
    readonly byId: Readonly<Partial<Record<K, {
        readonly blank?: boolean | undefined;
        readonly retainedBy?: {
            readonly mainView?: number;
        } | undefined;
    }>>>;
    readonly current?: string | undefined;
}, docked?: boolean): string | undefined;
export interface KnowledgeActivitySelection {
    mode?: 'knowledge' | 'notes';
    knowledgeBaseId?: string | undefined;
    documentId?: string | undefined;
    noteFolderId?: string | null | undefined;
    noteDocumentId?: string | undefined;
    noteCrumbs?: {
        id: string | null;
        name: string;
    }[];
}
/** A base change cannot carry the previous base's document into the next view. */
export declare function mergeActivitySelection(previous: KnowledgeActivitySelection, next: KnowledgeActivitySelection): KnowledgeActivitySelection;
//# sourceMappingURL=knowledge-activity-state.d.ts.map