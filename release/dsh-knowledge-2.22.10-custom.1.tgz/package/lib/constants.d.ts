/** Host settings namespace that makes the knowledge connection card discoverable. */
export declare const KNOWLEDGE_SETTINGS_NAMESPACE = "dsh-knowledge-connection";
//# sourceMappingURL=constants.d.ts.map