import type { KnowledgeProvider } from './provider.js';
import { type KnowledgeHandleCodec } from './retrieval.js';
import type { RuntimeContextLike, ToolDefinitionLike } from './runtime.js';
import { KnowledgeNoteHandleCodec } from './note-reference-handle.js';
export declare function registerKnowledgeNoteReferenceTools(ctx: RuntimeContextLike, provider: KnowledgeProvider, knowledgeCodec: KnowledgeHandleCodec, noteCodec: KnowledgeNoteHandleCodec, register?: (tool: ToolDefinitionLike) => () => void): void;
//# sourceMappingURL=note-reference-tools.d.ts.map