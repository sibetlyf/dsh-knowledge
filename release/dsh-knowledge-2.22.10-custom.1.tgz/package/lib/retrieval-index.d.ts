import type { DatabaseSync } from 'node:sqlite';
import type { KnowledgeEntry } from './domain.js';
import { buildPassageStructure } from './retrieval-passages.js';
/** Derived data only. Older plugin versions can ignore these additive tables. */
export declare const PASSAGE_INDEX_VERSION = 1;
export interface RetrievalIndexScope {
    baseIds?: string[];
    projectId?: string;
    scoped?: boolean;
    mounts?: {
        knowledgeBaseId: string;
        includeTags: string[];
        excludeTags: string[];
    }[];
}
export declare class RetrievalIndex {
    private readonly db;
    private readonly build;
    private timer;
    private closed;
    constructor(db: DatabaseSync, build?: typeof buildPassageStructure);
    private schedule;
    /** No model/network calls, and no whole-library rebuild in the search path. */
    processBatch(limit?: number, now?: number): number;
    passage(entry: KnowledgeEntry, query: string): {
        passage: import("./retrieval-passages.js").KnowledgePassage;
        retrieval: {
            source: "index";
            indexVersion: number;
            documentVersion: number;
        };
    } | {
        passage: import("./retrieval-passages.js").KnowledgePassage;
        retrieval: {
            source: "fallback";
            indexVersion: number;
            documentVersion: number;
        };
    };
    /** Scoped metadata only. Details are paged separately from the cheap summary. */
    status(scope?: RetrievalIndexScope, options?: {
        details?: boolean;
        state?: 'pending' | 'failed';
        offset?: number;
    }): {
        total: number;
        failures: Record<string, import("node:sqlite").SQLOutputValue>[];
        items: Record<string, import("node:sqlite").SQLOutputValue>[];
        state: "pending" | "failed";
        offset: number;
        hasMore: boolean;
        ready: number;
        pending: number;
        failed: number;
        indexVersion: number;
    };
    retryFailed(scope?: RetrievalIndexScope, documentId?: string): number;
    close(): void;
}
//# sourceMappingURL=retrieval-index.d.ts.map