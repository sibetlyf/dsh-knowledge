/** Group names are metadata, never filesystem paths or search permissions. */
export interface KnowledgeDocumentGroup {
    name: string;
    count: number;
}
export declare function normalizeDocumentGroup(value: unknown, required?: boolean): string;
export declare function matchDocumentGroup(value: string, existing: readonly string[]): string;
//# sourceMappingURL=document-groups.d.ts.map