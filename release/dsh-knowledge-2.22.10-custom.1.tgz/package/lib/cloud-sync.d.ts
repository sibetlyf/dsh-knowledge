export interface CloudSyncConfig {
    url: string;
    token: string;
    userName: string;
    autoSync: boolean;
    intervalMinutes: number;
    filesDir: string;
    filesOut: string;
    base: string;
}
export interface CloudSyncConfigInput {
    url?: string;
    token?: string;
    userName?: string;
    autoSync?: boolean;
    intervalMinutes?: number;
    filesDir?: string;
    filesOut?: string;
    base?: string;
}
export interface CloudSyncStatus {
    configured: boolean;
    url: string;
    userName: string;
    autoSync: boolean;
    intervalMinutes: number;
    filesDir: string;
    filesOut: string;
    base: string;
    running: boolean;
    mode?: string;
    lastRunAt?: string;
    lastError?: string;
    lastOutput?: string;
}
export interface CloudSyncControl {
    status(): Promise<CloudSyncStatus>;
    configure(input: CloudSyncConfigInput): Promise<CloudSyncStatus>;
    run(mode: 'push' | 'pull' | 'sync'): Promise<CloudSyncStatus>;
    scheduleSoon(): void;
}
export declare class CloudSyncManager implements CloudSyncControl {
    private config;
    private readonly configPath;
    private readonly scriptPath;
    private readonly databasePath;
    private readonly logger;
    private timer;
    private debounce;
    private child;
    private readonly ready;
    private running;
    private mode;
    private lastRunAt;
    private lastError;
    private lastOutput;
    constructor(options: {
        databasePath: string;
        logger: {
            warn: (message: string) => void;
        };
    });
    private load;
    private save;
    status(): Promise<CloudSyncStatus>;
    configure(input: CloudSyncConfigInput): Promise<CloudSyncStatus>;
    run(mode: 'push' | 'pull' | 'sync'): Promise<CloudSyncStatus>;
    dispose(): void;
    scheduleSoon(): void;
    private applyTimer;
    private execute;
    private executeOne;
}
//# sourceMappingURL=cloud-sync.d.ts.map