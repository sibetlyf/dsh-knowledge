export interface TencentDocsTokenStatus {
    configured: boolean;
    source: 'env' | 'vault' | 'none';
    fingerprint: string;
    overriddenByEnv: boolean;
}
export declare function tencentDocsVaultPath(env?: NodeJS.ProcessEnv): string;
export declare function isValidTencentDocsToken(token: string): boolean;
/** Effective token status. Never returns the token itself. */
export declare function readTencentDocsToken(env?: NodeJS.ProcessEnv, path?: string): Promise<TencentDocsTokenStatus & {
    token: string;
}>;
/** Persist a user-entered token into the local bridge vault (mode 0600). */
export declare function saveTencentDocsToken(token: string, env?: NodeJS.ProcessEnv, path?: string): Promise<TencentDocsTokenStatus>;
/** Remove the persisted token so the bridge watcher unmounts its MCP client. */
export declare function clearTencentDocsToken(env?: NodeJS.ProcessEnv, path?: string): Promise<TencentDocsTokenStatus>;
//# sourceMappingURL=tencent-docs-token.d.ts.map