/** Only visible turn tails own status reads and live subscriptions. */
export declare function observeWritebackVisibility(element: HTMLElement, status: {
    setVisible(visible: boolean): void;
}, subscribe: () => () => void): () => void;
//# sourceMappingURL=status-visibility.d.ts.map