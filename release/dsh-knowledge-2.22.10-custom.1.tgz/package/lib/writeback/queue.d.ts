import type { ExtractionWriteDestination } from '../domain.js';
import type { ExtractionCheckpoint, TurnSnapshot } from '../extraction.js';
export interface WritebackStatus {
    status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
    summary: string;
    error?: string;
    retryable: boolean;
    destinations?: ExtractionWriteDestination[];
    nextAttemptAt?: number;
    blockedBy?: string;
    buffered?: boolean;
    batchSize?: number;
    cancelRequested?: boolean;
}
export interface WritebackWork {
    snapshot: TurnSnapshot;
    destination: string;
}
export interface WritebackFrequency {
    everyTurns: number;
    idleSeconds: number;
    maxChars: number;
}
export declare class WritebackDeferred extends Error {
}
/** Local durable outbox. No network/LLM work runs on enqueue or manual retry. */
export declare class WritebackQueue {
    private readonly execute;
    private readonly warn;
    private readonly frequency;
    private readonly db;
    private readonly owner;
    private timer;
    private active;
    private controller;
    private activeKey;
    private closed;
    private started;
    private notifiedRevision;
    private closing;
    private readonly listeners;
    subscribe(listener: () => void): () => void;
    get revision(): string;
    private notify;
    constructor(path: string, execute: (work: WritebackWork, checkpoint: ExtractionCheckpoint, signal: AbortSignal) => Promise<WritebackStatus>, warn?: (message: string) => void, frequency?: () => WritebackFrequency);
    enqueue(work: WritebackWork): WritebackStatus;
    completeEmpty(sourceKey: string, sessionId: string): WritebackStatus;
    private leader;
    status(key: string): WritebackStatus | undefined;
    retry(key: string): WritebackStatus;
    list(sessionId?: string, offset?: number, limit?: number, status?: WritebackStatus['status']): {
        total: number;
        items: {
            status: "queued" | "running" | "completed" | "failed" | "cancelled";
            summary: string;
            error?: string;
            retryable: boolean;
            destinations?: ExtractionWriteDestination[];
            nextAttemptAt?: number;
            blockedBy?: string;
            buffered?: boolean;
            batchSize?: number;
            cancelRequested?: boolean;
            sourceKey: string;
            sessionId: string;
            attempts: number;
            createdAt: number | null;
        }[];
    };
    listPage(sessionId?: string, status?: WritebackStatus['status'], cursor?: string, watch?: string[]): {
        total: number;
        items: {
            status: "queued" | "running" | "completed" | "failed" | "cancelled";
            summary: string;
            error?: string;
            retryable: boolean;
            destinations?: ExtractionWriteDestination[];
            nextAttemptAt?: number;
            blockedBy?: string;
            buffered?: boolean;
            batchSize?: number;
            cancelRequested?: boolean;
            sourceKey: string;
            sessionId: string;
            attempts: number;
            createdAt: number | null;
        }[];
        updates: {
            status: "queued" | "running" | "completed" | "failed" | "cancelled";
            summary: string;
            error?: string;
            retryable: boolean;
            destinations?: ExtractionWriteDestination[];
            nextAttemptAt?: number;
            blockedBy?: string;
            buffered?: boolean;
            batchSize?: number;
            cancelRequested?: boolean;
            sourceKey: string;
            sessionId: string;
            attempts: number;
            createdAt: number | null;
        }[];
        nextCursor: string | undefined;
    };
    cancel(key: string): WritebackStatus;
    private finishCancellation;
    start(): void;
    get isRunning(): boolean;
    private kick;
    /** Explicit flush never reruns a completed batch. */
    flush(key: string): WritebackStatus;
    /** Called under the queue lease transaction. Only fresh, unattempted snapshots
     * can merge; retries keep their exact frozen payload/checkpoint. */
    private prepareBatches;
    private claim;
    private drain;
    close(): Promise<void>;
}
//# sourceMappingURL=queue.d.ts.map