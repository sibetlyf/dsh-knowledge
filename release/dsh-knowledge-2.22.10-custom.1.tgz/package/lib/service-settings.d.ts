export interface KnowledgeServiceSettings {
    publicApiEnabled: boolean;
    writebackProvider?: string;
    writebackModel?: string;
    extractionEveryTurns?: number;
    extractionIdleSeconds?: number;
}
export declare function serviceSettingsPath(connectionPath: string | undefined): string | undefined;
export declare function loadServiceSettings(path: string | undefined): KnowledgeServiceSettings | undefined;
export declare function storeServiceSettings(path: string, settings: KnowledgeServiceSettings): Promise<void>;
/** Shared validation for local settings, remote-client settings and persisted state. */
export declare function normalizeWritebackFrequency(value: Record<string, unknown>): {
    extractionEveryTurns?: number;
    extractionIdleSeconds?: number;
};
//# sourceMappingURL=service-settings.d.ts.map