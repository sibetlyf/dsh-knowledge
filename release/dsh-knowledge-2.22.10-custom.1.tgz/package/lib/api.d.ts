import { type NoteWorkspace } from './notes/workspace-http.js';
import type { IncomingMessage } from 'node:http';
import { LocalKnowledgeProvider } from './local-provider.js';
import type { RuntimeContextLike } from './runtime.js';
import { type NoteShareRequestPolicy } from './notes/share-import.js';
import type { KnowledgeShareStore } from './knowledge-share.js';
import type { CloudSyncControl } from './cloud-sync.js';
export declare const LOCAL_MANAGEMENT_API_PREFIX = "/knowledge-local/v1";
export interface KnowledgeApiOptions {
    noteWorkspace?: NoteWorkspace;
    worklog?: (method: string, path: string, data: Record<string, unknown>, query: URLSearchParams) => Promise<unknown>;
    worklogBrowser?: (method: string, path: string, data: Record<string, unknown>, query: URLSearchParams) => Promise<unknown>;
    shareRequestPolicy?: () => NoteShareRequestPolicy;
    knowledgeShares?: KnowledgeShareStore;
    cloudSync?: CloudSyncControl;
    tencentDocs?: {
        status(signal?: AbortSignal): Promise<unknown>;
        saveToken(token: string): Promise<unknown>;
        clearToken(): Promise<unknown>;
        importDocument(input: {
            url: string;
            knowledgeBaseId?: string;
            title?: string;
            group?: string;
        }, signal?: AbortSignal): Promise<unknown>;
        publish(documentId: string, signal?: AbortSignal): Promise<unknown>;
    };
    morning?: (day?: string, signal?: AbortSignal) => Promise<unknown>;
    authMode?: 'bearer' | 'same-origin';
    service?: {
        current(): {
            publicApiEnabled: boolean;
            publicApiPrefix: string;
            writebackProvider?: string;
            writebackModel?: string;
            extractionEveryTurns?: number;
            extractionIdleSeconds?: number;
        };
        update(patch: {
            publicApiEnabled?: boolean;
            writebackProvider?: string | null;
            writebackModel?: string | null;
            extractionEveryTurns?: number;
            extractionIdleSeconds?: number;
        }): Promise<{
            publicApiEnabled: boolean;
            publicApiPrefix: string;
            writebackProvider?: string;
            writebackModel?: string;
            extractionEveryTurns?: number;
            extractionIdleSeconds?: number;
        }>;
    };
}
export declare function registerKnowledgeApi(ctx: RuntimeContextLike, provider: LocalKnowledgeProvider, prefix: string, options?: KnowledgeApiOptions): () => void;
export declare function assertKnowledgeBrowserRequest(req: IncomingMessage, client: 'management-web' | 'conversation-web'): void;
//# sourceMappingURL=api.d.ts.map