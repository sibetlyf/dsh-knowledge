import type { RuntimeContextLike, ToolDefinitionLike, ToolRunContextLike } from './runtime.js';
import type { NoteMutationPreview } from './note-edit-plan.js';
export declare function renderNoteToolOutput(value: unknown): Array<{
    type: 'text';
    text: string;
}>;
export declare function isNoteConfirmation(text: string): boolean;
export declare function requestNoteConfirmation(exec: ToolRunContextLike, reason: string, preview?: NoteMutationPreview): void;
/** Pending plans are server-owned, session-bound, bounded and deliberately not
 * restored after restart. Confirmation never accepts replacement tool args. */
export declare function noteConfirmationTools(ctx: RuntimeContextLike, register?: (tool: ToolDefinitionLike) => () => void): (tool: ToolDefinitionLike) => ToolDefinitionLike;
//# sourceMappingURL=note-confirmation.d.ts.map