/** A quoted document name is still a name, not a request to search the quote marks. */
export declare function documentTitleQuery(value: string): string;
export declare function buildSearchQuery(userText: string, assistantText?: string): string;
//# sourceMappingURL=search-query.d.ts.map