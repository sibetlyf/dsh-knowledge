/** Shared read-only document body. Headings come from the sanitized rendered DOM,
 * so code fences, duplicate names and inline formatting match the actual page. */
export declare function KnowledgeActivityMarkdown({ html }: {
    html: string;
}): JSX.Element;
//# sourceMappingURL=knowledge-activity-markdown.d.ts.map