import type { ResolvedUpload } from './archive.js';
import type { ArtifactUploadCandidate } from './collect.js';
/** Minimal structural view of the Host `attachments` service. */
export interface AttachmentStoreLike {
    fileHostPath?(ref: unknown): string | undefined;
    imageHostPath?(ref: unknown): string | undefined;
    readFileStream?(ref: unknown, signal?: AbortSignal): AsyncIterable<Uint8Array>;
    readImage?(ref: unknown, signal?: AbortSignal): Promise<{
        data: Uint8Array;
        ref?: {
            mediaType?: string;
        };
    }>;
}
export interface UploadReaderOptions {
    /** Resolved Host services; read lazily so plugin activation never depends on them. */
    get(name: string): unknown;
    /** Upper bound on bytes buffered for one upload. */
    maxBytes: number;
    logger: {
        warn(message: string): void;
    };
}
/**
 * Read one uploaded attachment into memory for archiving.
 *
 * Uploads live in the Host attachment store, not in the workspace, so they are
 * resolved through the `attachments` service instead of a filesystem path.
 * File streams are verified by the service; images are normalized on admission
 * and therefore archive the normalized bytes that history references.
 */
export declare function createUploadReader(options: UploadReaderOptions): (upload: ArtifactUploadCandidate) => Promise<ResolvedUpload | undefined>;
//# sourceMappingURL=uploads.d.ts.map