import type { SessionLike } from '../runtime.js';
/** One uploaded attachment carried by a user prompt. */
export interface ArtifactUploadCandidate {
    kind: 'file' | 'image';
    /** Durable attachment reference as it appears in the session log. */
    ref: Record<string, unknown>;
    name: string;
    mediaType?: string;
}
/** Every source that can contribute a file to the archive. */
export type ArtifactSource = 'presented' | 'file-tool' | 'upload' | 'reference' | 'workspace-change' | 'folder';
/** One file involved in a completed turn. */
export interface ArtifactCandidate {
    /** Absolute path, or a path relative to the Session working directory. */
    path?: string;
    upload?: ArtifactUploadCandidate;
    source: ArtifactSource;
    description?: string;
}
/**
 * Collect every file involved in one completed turn.
 *
 * Durable signals are used instead of watching the filesystem:
 * - `deliverables/presented` declares deliverables, including shell-produced files;
 * - `tool/call` arguments name every file a tool read, viewed, converted, wrote or edited;
 * - shell command strings contribute path-like tokens that exist on disk;
 * - `@path` references in the user's message name files the user brought in;
 * - `user/message` file/image blocks are uploaded attachments.
 *
 * Reading the turn's own event slice keeps the result deterministic across
 * resumes. The archiver still validates each candidate (existence, regular
 * file, size, exclusions), so command or prose tokens never invent files.
 */
export declare function collectTurnArtifacts(session: SessionLike, turn: number): ArtifactCandidate[];
/** Latest model route used by this session; a fallback for background worklog generation. */
export declare function lastAssistantRoute(session: SessionLike): {
    provider: string;
    model: string;
} | undefined;
/** Walk tool arguments and collect paths, including nested `files: [{path}]` shapes. */
export declare function collectArgumentPaths(args: Record<string, unknown>): string[];
//# sourceMappingURL=collect.d.ts.map