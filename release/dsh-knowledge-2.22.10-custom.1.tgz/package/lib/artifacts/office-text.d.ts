/**
 * Dependency-free text extraction for Office Open XML and OpenDocument
 * artifacts. The archiver indexes the user-visible text so archived deck,
 * report and spreadsheet deliverables stay searchable in the knowledge base.
 * Only container members are read; macros, embedded objects and images are
 * never executed or inflated beyond the shared zip bounds.
 */
export type OfficeKind = 'docx' | 'pptx' | 'xlsx' | 'odf';
/** Normalized Office kind for one extension, or undefined for other files. */
export declare function officeKind(extension: string): OfficeKind | undefined;
/** Extract bounded plain text from an Office/ODF buffer; never throws for unknown content. */
export declare function extractOfficeText(extension: string, buffer: Buffer, maxChars: number): string;
/** Flatten one WordprocessingML/presentation/ODF XML member into plain text. */
export declare function xmlText(xml: string): string;
export declare function decodeEntities(value: string): string;
//# sourceMappingURL=office-text.d.ts.map