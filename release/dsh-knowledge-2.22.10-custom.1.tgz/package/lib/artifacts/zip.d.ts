export interface ReadZipOptions {
    /** Keep only members accepted by this predicate; other members are skipped. */
    match?: (name: string) => boolean;
    /** Maximum number of members read (default 256). */
    maxEntries?: number;
    /** Maximum bytes any single member may inflate to (default 16 MiB). */
    maxEntryBytes?: number;
    /** Maximum bytes all selected members may inflate to (default 32 MiB). */
    maxTotalBytes?: number;
}
export declare function readZipEntries(buffer: Buffer, options?: ReadZipOptions): Map<string, Buffer>;
//# sourceMappingURL=zip.d.ts.map