/** File types archived by default: documents, tabular data and images. */
export declare const DEFAULT_ARTIFACT_EXTENSIONS: string[];
export type ArtifactContentKind = 'text' | 'office' | 'pdf' | 'image' | 'binary';
export interface ArtifactContent {
    kind: ArtifactContentKind;
    text: string;
    /** True when the indexed text was cut at the configured limit. */
    truncated: boolean;
    note?: string;
}
/** Lowercase extension without the leading dot; empty when the name has none. */
export declare function normalizeExtension(pathOrExtension: string): string;
/** Human-readable artifact category used as the default document column. */
export declare function artifactCategory(extension: string): string;
export declare function artifactMediaType(extension: string): string;
/** Best-effort extension for a known media type (uploads may arrive unnamed). */
export declare function extensionForMediaType(mediaType: string | undefined): string;
export declare function artifactContentKind(extension: string): ArtifactContentKind;
/**
 * Extract the searchable text of one archived artifact.
 *
 * Binaries and images keep metadata only: the archive copy stays authoritative,
 * and the knowledge entry never claims to contain bytes it did not read.
 */
export declare function extractArtifactContent(extension: string, buffer: Buffer, maxChars: number): ArtifactContent;
//# sourceMappingURL=text.d.ts.map