import type { KnowledgeProvider } from '../provider.js';
import type { SessionLike } from '../runtime.js';
import type { KnowledgeWriteEvent } from '../knowledge-events.js';
import { type ArtifactCandidate, type ArtifactUploadCandidate } from './collect.js';
import { type ArtifactContent } from './text.js';
/** One archived artifact version. `path` is absolute, or the uploaded file name. */
export interface ArtifactRecord {
    id: string;
    path: string;
    display: string;
    sha256: string;
    size: number;
    extension: string;
    mediaType: string;
    contentKind: ArtifactContent['kind'];
    source: ArtifactCandidate['source'];
    description?: string;
    sessionId?: string;
    turn?: number;
    archivedAt: string;
    updatedAt: string;
    version: number;
    blob: string;
    knowledgeBaseId: string;
    entryId: string;
    textChars: number;
}
export interface ArtifactLogger {
    info(message: string): void;
    warn(message: string): void;
}
/** Bytes of one uploaded attachment read through the Host attachment service. */
export interface ResolvedUpload {
    name: string;
    bytes: Buffer;
    mediaType?: string;
}
export interface ArtifactArchiverOptions {
    /** Directory holding `index.json` and the content-addressed `blobs/` tree. */
    root: string;
    provider: KnowledgeProvider;
    /** Knowledge base that receives one document per artifact path. */
    baseName: string;
    /** Lowercase extensions without a dot; `*` captures every written file. */
    extensions: readonly string[];
    /** Glob-like patterns excluded from capture (matched on the display path). */
    excludePatterns: readonly string[];
    maxFileBytes: number;
    /** Maximum indexed characters per artifact document. */
    maxContentChars: number;
    /**
     * Embed extracted text in the knowledge document. Off by default: the
     * database keeps metadata, keywords and a link to the file on disk.
     */
    storeContent?: boolean;
    /** Upper bound on manifest records; the least recently updated are dropped. */
    maxEntries: number;
    /** Mount the artifact base for recall on the artifact's project. */
    autoMount: boolean;
    /** Recognize PDF papers and file them in the paper base with metadata. */
    paperEnabled?: boolean;
    /** Knowledge base that receives papers; created once on first paper. */
    paperBaseName?: string;
    /** Reads uploaded attachment bytes; absent when the Host has no attachment service. */
    resolveUpload?: (upload: ArtifactUploadCandidate) => Promise<ResolvedUpload | undefined>;
    /** Called after a new artifact document version is stored; feeds the work journal. */
    onArchived?: (event: KnowledgeWriteEvent) => void;
    logger: ArtifactLogger;
    now?: () => Date;
}
export interface ArtifactIngestContext {
    sessionId: string;
    cwd?: string;
    turn: number;
    /** Session model route, used as a worklog generation fallback. */
    route?: {
        provider: string;
        model: string;
    };
}
export type ArtifactIngestAction = 'created' | 'updated' | 'unchanged' | 'skipped' | 'failed';
export interface ArtifactIngestItem {
    path: string;
    display: string;
    action: ArtifactIngestAction;
    entryId?: string;
    /** Why a candidate was skipped or failed. */
    reason?: string;
    bytes?: number;
    /** Display category used by the artifact browser. */
    category?: string;
    knowledgeBaseId?: string;
    knowledgeBaseName?: string;
    group?: string;
    paper?: {
        title: string;
        categories: string[];
    };
}
export interface ArtifactIngestSummary {
    captured: number;
    updated: number;
    unchanged: number;
    skipped: number;
    failed: number;
    items: ArtifactIngestItem[];
}
export interface ArtifactArchiveStatus {
    /** Capture passes waiting behind the active one. */
    queued: number;
    active: boolean;
    total: number;
    done: number;
    current?: string;
    last?: {
        at: number;
        captured: number;
        updated: number;
        unchanged: number;
        skipped: number;
        failed: number;
    };
}
/**
 * Archive files produced by completed turns and index them as knowledge.
 *
 * Product behavior:
 * - the plugin captures declared deliverables (`present`), files written by
 *   file tools, and attachments the user uploaded, as soon as a turn stops,
 *   with no review or confirmation step;
 * - every version of an artifact is kept byte-for-byte in a content-addressed
 *   archive next to the knowledge database;
 * - one knowledge document per artifact is created or updated in place, so its
 *   version history and search index follow the artifact;
 * - documents are grouped per project and the artifact knowledge base is
 *   mounted for recall on the producing project.
 */
export declare class ArtifactArchiver {
    private readonly options;
    private readonly root;
    private readonly extensions;
    private readonly patterns;
    private readonly storeContent;
    private readonly logger;
    private readonly now;
    private readonly records;
    private readonly verifiedEntries;
    private readonly mountedProjects;
    private loading;
    private loaded;
    private dirty;
    private closed;
    private baseId;
    private paperBaseId;
    private tail;
    private queuedBatches;
    private activeBatch;
    private lastCompletion;
    constructor(options: ArtifactArchiverOptions);
    /** Artifacts produced by one completed turn, read from its session events. */
    collectTurn(session: SessionLike, turn: number): ArtifactCandidate[];
    /**
     * Queue one bounded capture pass. Passes run one at a time so concurrent
     * turns cannot create duplicate documents for the same artifact path.
     */
    ingest(candidates: readonly ArtifactCandidate[], context: ArtifactIngestContext): Promise<ArtifactIngestSummary>;
    /** Snapshot used by the management console's background activity indicator. */
    status(): ArtifactArchiveStatus;
    /** Resolve and start one capture pass without waiting for it. */
    schedule(candidates: readonly ArtifactCandidate[], context: ArtifactIngestContext): void;
    /** Archive records, most recently updated first. */
    list(): Promise<ArtifactRecord[]>;
    /** Read one archived copy by its stable record id. */
    read(id: string): Promise<{
        record: ArtifactRecord;
        bytes: Buffer;
    } | undefined>;
    /** Wait for queued passes (used by tests and shutdown). */
    flush(): Promise<void>;
    close(): Promise<void>;
    private run;
    private captureCandidate;
    private store;
    private itemDetails;
    private notifyArchived;
    private entryUsable;
    private createOrRecover;
    private ensureBase;
    private ensureMount;
    private buildDraft;
    private displayPath;
    private isExcluded;
    private blobPath;
    private writeBlob;
    private load;
    private readManifest;
    private persist;
    private prune;
}
/** Group artifact documents by their file category so one base stays browsable. */
export declare function artifactGroup(extension: string): string;
/** Bounded term-frequency keywords used for indexing and cross-format links. */
export declare function extractArtifactKeywords(text: string, limit?: number): string[];
/** Convert the small glob dialect used by configuration into a RegExp. */
export declare function globToRegExp(pattern: string): RegExp;
//# sourceMappingURL=archive.d.ts.map