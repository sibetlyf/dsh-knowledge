export interface FolderScanResult {
    root: string;
    files: string[];
    truncated: boolean;
    skipped: number;
}
export interface FolderScanOptions {
    maxFiles?: number;
    /** Glob-like matchers applied to the path relative to the selected root. */
    excludePatterns?: readonly RegExp[];
    /** Paths that must never be entered (archive root, data directory). */
    excludeRoots?: readonly string[];
}
/**
 * Recursively enumerate regular files in a user-selected folder. The scanner
 * is bounded and never follows symlinks, so a folder import cannot escape the
 * selected tree or walk an entire drive.
 */
export declare function scanFolder(root: string, options?: FolderScanOptions): Promise<FolderScanResult>;
export declare function isAbsoluteFolderPath(value: string): boolean;
//# sourceMappingURL=folder-import.d.ts.map