export interface PaperMetadata {
    title: string;
    abstract: string;
    keywords: string[];
    /** Display categories; the first one becomes the document group. */
    categories: string[];
    /** Raw arXiv category codes (e.g. cs.CL). */
    codes: string[];
    arxivId?: string;
    doi?: string;
    year?: number;
}
/**
 * Deterministic metadata extraction for PDF papers. The abstract and keywords
 * become searchable database fields; the full paper still stays in the archive
 * file. No model call is made, so a malformed PDF never blocks archiving.
 */
export declare function extractPaperMetadata(text: string, display: string): PaperMetadata | undefined;
/** Category labels used for groups/tags; deterministic and bounded. */
export declare function categorize(codes: string[], keywords: string[], text: string): string[];
//# sourceMappingURL=paper.d.ts.map