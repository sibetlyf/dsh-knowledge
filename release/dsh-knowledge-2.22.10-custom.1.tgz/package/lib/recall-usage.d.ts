import type { KnowledgeProvider } from './provider.js';
import type { AgentLike } from './runtime.js';
import type { RecallUsage } from './recall-ranking.js';
/** Capture the provider before retrieval so a connection switch cannot cross-write usage. */
export declare function usageRecorder(provider: KnowledgeProvider, agent: AgentLike, explicitTurn?: number): (kind: RecallUsage["kind"], ids: string[]) => void;
//# sourceMappingURL=recall-usage.d.ts.map