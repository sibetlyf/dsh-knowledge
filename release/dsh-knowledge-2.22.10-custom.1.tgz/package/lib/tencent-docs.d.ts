import type { KnowledgeProvider } from './provider.js';
import type { RuntimeContextLike } from './runtime.js';
import { type TencentDocsTokenStatus } from './tencent-docs-token.js';
export interface TencentDocsStatus {
    connected: boolean;
    tools: string[];
    endpoint: string;
    token: TencentDocsTokenStatus;
}
export interface TencentDocsImportInput {
    url: string;
    knowledgeBaseId?: string;
    title?: string;
    group?: string;
}
export interface TencentDocsImportResult {
    documentId: string;
    title: string;
    knowledgeBaseId: string;
    group: string;
    relPath?: string;
    sourceUrl: string;
}
export interface TencentDocsPublishResult {
    documentId: string;
    title: string;
    url?: string;
}
/** Local knowledge <-> Tencent Docs bridge. Uses the already-mounted official MCP tools. */
export declare function createTencentDocsBridge(ctx: RuntimeContextLike, provider: KnowledgeProvider): {
    status: () => Promise<TencentDocsStatus>;
    saveToken(token: string): Promise<TencentDocsStatus>;
    clearToken(): Promise<TencentDocsStatus>;
    importDocument(input: TencentDocsImportInput, signal?: AbortSignal): Promise<TencentDocsImportResult>;
    publish(documentId: string, signal?: AbortSignal): Promise<TencentDocsPublishResult>;
};
//# sourceMappingURL=tencent-docs.d.ts.map