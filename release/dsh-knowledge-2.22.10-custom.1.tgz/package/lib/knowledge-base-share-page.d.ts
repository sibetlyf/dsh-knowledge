export interface KnowledgeBaseShareDocument {
    id: string;
    title: string;
    relPath?: string;
    body: string;
}
export interface KnowledgeBaseSharePageInput {
    apiPrefix: string;
    token: string;
    baseName: string;
    documents: KnowledgeBaseShareDocument[];
    selectedId?: string;
    truncated?: boolean;
}
export declare function renderKnowledgeBaseSharePage(input: KnowledgeBaseSharePageInput): string;
//# sourceMappingURL=knowledge-base-share-page.d.ts.map