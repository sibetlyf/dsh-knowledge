/** Durable navigation metadata, never a credential or a grant of read access. */
export interface KnowledgeCitation {
    documentId: string;
    knowledgeBaseId: string;
    sessionId: string;
    sourceKey: string;
    projectId?: string;
    title: string;
    version: number;
    startLine: number;
    endLine: number;
}
export declare const CITATION_PREFIX = "/knowledge/cite/";
export declare function encodeCitation(value: KnowledgeCitation): string;
export declare function parseCitation(raw: string): KnowledgeCitation | undefined;
export declare function citationFromHref(href: string, origin: string): KnowledgeCitation | undefined;
/** The official Markdown file-link button exposes its already-decoded path. */
export declare function citationFromFilePath(path: string): KnowledgeCitation | undefined;
export declare function citationMarkdown(value: KnowledgeCitation): string;
//# sourceMappingURL=knowledge-citations.d.ts.map