import type { KnowledgeProvider } from './provider.js';
import type { ToolDefinitionLike } from './runtime.js';
import { KnowledgeHandleCodec } from './retrieval.js';
/** Recall feedback is separate from document editing and never changes its version. */
export declare function recallIncidentTool(provider: KnowledgeProvider, codec: KnowledgeHandleCodec): ToolDefinitionLike;
//# sourceMappingURL=recall-incident-tool.d.ts.map