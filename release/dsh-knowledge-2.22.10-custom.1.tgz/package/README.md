# DSH Knowledge

面向 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的知识库、笔记与工作日报插件。支持本地使用和远程中央知识库，不修改 DSH Agent Loop。

[![GitHub](https://img.shields.io/badge/GitHub-sibetlyf%2Fdsh--knowledge-blue)](https://github.com/sibetlyf/dsh-knowledge)
[![Release](https://img.shields.io/github/v/release/sibetlyf/dsh-knowledge?display_name=tag)](https://github.com/sibetlyf/dsh-knowledge/releases)

## 独立团队知识库

`cloud/` 提供一个不需要安装 DSH 的独立团队知识库服务：浏览器登录、成员邀请、角色权限、共同编辑与版本冲突保护，另有任意类型文件库和 `cloud/sync-local.mjs` 本地知识库同步工具。插件设置页还提供「云端同步」卡片，连接后自动建立本地镜像并双向同步。部署方式见 [cloud/README.md](cloud/README.md)。这是独立服务，不会改变 DSH 插件本身的本地/远程模式。

## 功能

- 文件库与知识文档支持 PDF、DOCX、XLSX、PPTX、EPUB、RTF、Markdown 和文本解析；旧版 `.xls` 需要另存为 `.xlsx`，图片与扫描件在未配置 OCR 时明确标记为仅存储，不伪造索引。
- 知识库与文档分组、全文检索、项目和会话挂载，按权限召回与回写。
- 会话只暴露一个 `knowledge` 工具入口，按需发现、查看参数和执行 19 项知识库／笔记操作；不改变挂载和确认权限。见[统一工具入口](docs/tool-entry.md)。
- 回答完成后在后台独立提取知识，提供审核、版本历史、冲突保护、任务重试与文档封存。
- 独立笔记文档与目录：编辑、预览、分享、历史恢复；输入框 `@` 可搜索并引用笔记文档及上传的可编辑文本文件（Markdown、纯文本、代码和配置文件）。
- 内置工作日报：按本机工作目录选择采集范围，可显式包含子目录；支持补记、整理与导出，默认开启每天 23:30 的保底整理，可独立关闭，补充当天新增素材（按日报时区）。
- 云端自动 Wiki 草稿和团队日报汇总：本地日报随云端同步进入团队库，后台按日生成成员进展、阻塞和下一步汇总，支持手动重生成与发布标记。
- 本地 SQLite 或认证的中央知识服务，多个客户端可连接同一服务。

## 安装

需要 Node.js **>=24.9.0**。不按 DSH 版本号限制安装或加载；兼容性测试作为历史记录保留，见[宿主兼容策略](docs/host-compatibility-policy.md)。

### 方式一：预构建 tarball（推荐）

仓库自带已构建的安装包，DSH 可以直接安装，不需要执行 `prepare`，也不需要 `allowBuilds`：

```bash
dsh plugin --profile web add "https://raw.githubusercontent.com/sibetlyf/dsh-knowledge/main/release/dsh-knowledge-2.22.10-custom.1.tgz"
```

如果已经有旧版依赖，先移除再安装：

```bash
dsh plugin --profile web remove @lemoncat7/dsh-knowledge
dsh plugin --profile web add "https://raw.githubusercontent.com/sibetlyf/dsh-knowledge/main/release/dsh-knowledge-2.22.10-custom.1.tgz"
```

安装后确认版本：

```bash
dsh plugin --profile web list
```

必须显示 `2.22.10-custom.1`，而不是 `2.18.1`；然后重启对应 Profile，在「设置 → 插件 → 云端同步」查看。

### 方式二：本地构建

如果 tarball 下载受网络限制，可以本地构建：

```bash
git clone https://github.com/sibetlyf/dsh-knowledge.git
cd dsh-knowledge
npm ci
npm pack
dsh plugin --profile web add .\dsh-knowledge-*.tgz
```

> 如果你直接安装 GitHub 的 `archive/refs/heads/main.tar.gz`，那只是源码，不是预构建包；没有 `lib/client.js` 时，DSH 不会出现「云端同步」等新客户端功能。

> **安装后验证**：如果 DSH 报 `Cannot find module ...\@lemoncat7\dsh-knowledge\lib\index.js`，说明安装的是源码，`lib/` 没有构建出来。执行上面的 `npm ci && npm pack` 后，先确认 tarball 内存在：
>
> ```powershell
> tar -tzf .\lemoncat7-dsh-knowledge-2.22.10-custom.1.tgz |
>   Select-String 'package/lib/index.js'
> ```
>
> 有输出才安装；没有输出说明 `prepare/build` 失败或没有包含 `lib`。

> 安装日志里的 `@lemoncat7/dsh-knowledge@2.22.10-custom.1` 是 `package.json` 的包名和版本，不是第二个插件。

### 方式三：GitHub 源码

```bash
dsh plugin --profile web add github:sibetlyf/dsh-knowledge
```

GitHub 源码安装会执行 `prepare`，pnpm 默认会拦截构建；如果报 `allowBuilds`、`bad indentation of a mapping entry` 或 `@...@2.22.10-custom.1`，先修 Profile 的 `pnpm-workspace.yaml`，而不是反复重试。

### 修复 pnpm-workspace.yaml

文件位置：

```text
C:\Users\<用户名>\.dsh\profiles\web\pnpm-workspace.yaml
```

错误格式通常长这样：

```yaml
packages:
  - '.'
  soulmirror: true
  '@deepseek-ai/dsh-subprocess-loc...': true
  '@google/genai': true
```

缺少 `allowBuilds:` 这一级，导致 `bad indentation of a mapping entry`。改成：

```yaml
packages:
  - '.'

allowBuilds:
  soulmirror: true
  '@deepseek-ai/dsh-subprocess-loc...': true
  '@google/genai': true
  # 再把 pnpm 日志给出的本插件精确 key 加在这里
```

如果 pnpm 日志打印了其他精确 key，以日志中的 key 为准。修改后重新运行安装命令。

本地开发时，Profile 使用 link 依赖：

```json
"dsh-knowledge": "link:plugins/dsh-knowledge"
```

`plugins/dsh-knowledge` 指向当前仓库。

安装或升级后重启对应的 DSH Profile；`web` 请按实际使用的 Profile 调整。

打开侧栏「知识库」创建知识库，在「项目与会话挂载」选择使用范围和写入模式。笔记不需要先挂载知识库；工作日报在「工作记录」中单独开启采集。

## 使用边界

未挂载知识库不召回、不回写。笔记默认不参与知识自动回写，引用笔记不授予修改或删除权限；修改按工具确认流程执行。日报采集默认关闭，不补采历史会话。远程模式不做隐式双向同步；公开访问应配置认证，升级前备份数据。

## 文档

- [使用、权限与部署配置](docs/usage.md)
- [文档分组](docs/document-groups.md)
- [笔记 @ 引用](docs/note-mentions.md)
- [空闲读写与后台处理](docs/idle-performance.md)
- [版本与发布说明](https://github.com/sibetlyf/dsh-knowledge/releases)
- [发布维护约定](docs/releases/README.md)

### 2.17.2

新建笔记/目录及批量创建免确认；修改与删除已有内容仍需确认。详见 [版本说明](docs/releases/2.17.2.md)。

## 2.18.0 笔记离线副本与本地文件

笔记工作区增加远程补同步和可供 Obsidian 打开的 Markdown 目录。支持范围、冲突规则和 schema 升级注意事项见 [说明](docs/note-workspace-sync.md)。

本地文件索引仅在持久化状态变化时执行原子写入和落盘同步；空闲扫描保留索引文件的 inode 与修改时间。写入失败仍会在后续扫描中重试，实际笔记变更、冲突和移动检查点继续同步保存。


## 宿主兼容策略

DSH 更新后不再为了补版本声明单独发布插件；按实际接口和功能验证、修复。[策略及历史测试入口](docs/host-compatibility-policy.md)。

### 工作日历

工作记录新增每日目标与时间段日历，支持月/周视图、进度、改期、标签和回收站。AI 通过统一入口的 `knowledge_calendar` 操作管理；可导出 `.ics`，预留外部日历适配器。详见 [工作日历](docs/work-calendar.md)。

## 本分支保留的增强

- **欢迎页早晨卡片**：把工作日报、当天待办、会议助手状态收进一张浮动卡片；支持拖拽与双击复位，卡片上方即 DSH 新建会话的鲸鱼标。
- **每日待办与简报**：工作/生活分类、跨天承接、完成状态；`/worklog-control/v1/todos` 与 `/brief` 由同一份 SQLite 数据生成，日报生成时也会把待办写入素材。
- **周报/月报**：工作记录页可直接生成，按日聚合日报与待办；默认模型缺失时仍返回可读的模板正文，并明确标注未生成。
- **腾讯文档**：设置 → 腾讯文档 可保存 `space_secret`（只写本机 vault）；知识目录的「导入腾讯文档」和文档的「发布到腾讯文档」调用同一桥插件。
- **知识文档只读分享**：知识文档的「更多」菜单生成独立链接；链接本身携带随机访问令牌，缺少或错误令牌一律 404，不能匿名猜测访问；文档更新后内容随之更新，撤销后立即失效。
- **整个知识库分享**：知识库卡片上的「分享知识库」生成一个目录页链接；接收者可浏览该库的全部文档，点开任意一篇阅读，链接同样必须携带令牌，撤销立即失效。
- **工作日报只读分享**：工作日报页的「分享日报」生成同样的令牌链接；接收者看到全部有记录的日期、日报正文和当天待办，看不到采集设置、项目管理、来源会话或写操作。

公开分享页仍由当前 DSH WebServer 提供。接收者不需要 DSH 账号或 Bearer Token，但必须能访问你的 DSH 地址；要发给不在同一台机器上的人，必须让 DSH 的监听地址或反向代理对该用户可访问。反向代理上的登录保护若要保留，需要把 `/knowledge-local/v1/shared-knowledge/`、`/knowledge-local/v1/shared-base/` 和 `/knowledge-local/v1/shared-worklog/` 设为公开路径。分享链接中的令牌只授予对应页面的只读访问，不携带模型或账户凭据。
